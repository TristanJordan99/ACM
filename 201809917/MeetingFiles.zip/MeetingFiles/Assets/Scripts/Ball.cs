﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {
    public int JumpHeight = 300;
    public int MoveForce = 30;
    public GameObject RespawnPoint;

    private Rigidbody rigidbody;

	// Use this for initialization
	void Start () {
        print("I have a jump force of: " + JumpHeight);
        rigidbody = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void FixedUpdate () {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rigidbody.AddForce(Vector3.up * JumpHeight);
        }

        float hMove = Input.GetAxis("Horizontal");
        float vMove = Input.GetAxis("Vertical");

        rigidbody.AddForce(new Vector3(hMove, 0.0f, vMove));

	}

    private void OnTriggerEnter(Collider other)
    {
        print(other.name);
        if (other.tag == "Respawn")
        {
            print("Respawn");
            transform.position = RespawnPoint.transform.position;
        }
    }
}
