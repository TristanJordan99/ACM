﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour {
    private Vector3 Cam;
    public GameObject Sphere;
    // Use this for initialization
    void Start () {
        Cam = transform.position;
        DontDestroyOnLoad(this.gameObject);

    }
	
	// Update is called once per frame
	void LateUpdate () {
        transform.position = Sphere.transform.position + Cam;
	}
}
