﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Ball : MonoBehaviour {
    public int JumpHeight = 300;
    public int MoveForce = 30;
    public GameObject RespawnPoint;
    public Text scoreText;

    private Rigidbody rigidbody;
    private int score = 0;

	// Use this for initialization
	void Start () {
        rigidbody = GetComponent<Rigidbody>();
        DontDestroyOnLoad(this.gameObject);
        SceneManager.sceneLoaded += OnSceneLoaded;
        UpdateScoreText();
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rigidbody.AddForce(Vector3.up * JumpHeight);
        }

        float hMove = Input.GetAxis("Horizontal");
        float vMove = Input.GetAxis("Vertical");

        rigidbody.AddForce(new Vector3(hMove, 0.0f, vMove));

	}

    private void OnTriggerEnter(Collider other)
    {
        print(other.name);
        if (other.tag == "Respawn")
        {
            print("Respawn");
            Respawn();
        }else if (other.tag == "Finish")
        {
            Debug.Log("Next Level");
            SceneManager.LoadScene(1);
        }else if (other.tag == "Coin")
        {
            Destroy(other.gameObject);
            score += 15;
            UpdateScoreText();
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        RespawnPoint = GameObject.Find("RespawnPoint");
        Respawn();
    }

    private void Respawn()
    {
        transform.position = RespawnPoint.transform.position;
        rigidbody.velocity = Vector3.zero;
    }

    private void UpdateScoreText()
    {
        scoreText.text = "Score: " + score;
    }
}
