﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {
    public Text scoreText;
    static public GameManager current;
    private int score = 0;
	// Use this for initialization
	void Start () {
        current = this;
        UpdateScore();
	}

    void UpdateScore()
    {
        scoreText.text = "Score: " + score.ToString();
    }

    public void ButtonClick()
    {
        score++;
        UpdateScore();
    }

    public void AddScore(int amt)
    {
        score += amt;
        UpdateScore();
    }
}
