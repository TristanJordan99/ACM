﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AssetController : MonoBehaviour {
    public int cost = 10;
    public int award = 2;
    public float maxTime = 1f;
    public Text amtText;
    public Slider progressBar;

    private int num = 0;
    private float timer = 0f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        timer += Time.deltaTime;
        if (num != 0) { 
            progressBar.value = timer / maxTime;
            if (timer>maxTime)
            {
                GameManager.current.AddScore(num * award);
                timer = 0;
            }
        }
	}

    public void Buy()
    {
        GameManager.current.AddScore(-cost);
        num++;
    }
}
