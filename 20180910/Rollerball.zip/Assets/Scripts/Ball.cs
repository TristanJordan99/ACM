﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {
    public int JumpHeight = 300;

    private Rigidbody rigidbody;

	// Use this for initialization
	void Start () {
        print("I have a jump force of: " + JumpHeight);
        rigidbody = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rigidbody.AddForce(Vector3.up * JumpHeight);
        }
	}
}
